# alerobot

create bike object test preconfigured. add create bike app as additional step? in trial setup, creating additional
    # about creating CRT and setting up. look into creating package with config updates. QA person is the one building the test case.